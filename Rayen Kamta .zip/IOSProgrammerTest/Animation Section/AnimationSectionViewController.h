//
//  AnimationSectionViewController.h
//  IOSProgrammerTest
//
//  Created by Rayen Kamta on 08/12/2015.
//  Copyright (c) 2015 Rayen Kamta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationSectionViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageLogo;
- (IBAction)SpinButn;
@property (weak, nonatomic) IBOutlet UILabel *spinLabl;

@end
